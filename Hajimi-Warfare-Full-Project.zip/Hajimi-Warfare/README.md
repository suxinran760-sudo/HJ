# 哈基米枪战（Hajimi Warfare）

Godot 4.4.1 / Android 竖屏 FPS 原型。此仓库从头整理，包含游戏入口、程序化训练场、基础触屏操作、设置入口、局域网房间连接原型和 GitHub Actions 工作流。

## 项目结构

- `project.godot`：Godot 项目配置
- `scenes/main.tscn`：游戏主场景
- `scripts/main.gd`：训练场、玩家控制、HUD、基础射击、LAN 房间连接
- `assets/icon.png`：应用图标（由上传的猫咪图片裁切）
- `.github/workflows/android-apk.yml`：GitHub Actions APK 构建

## 用 Godot 打开

1. 安装 Godot **4.4.1 标准版**（非 .NET）。
2. 导入本目录的 `project.godot`。
3. 按 F6/F5 运行主场景。
4. 桌面 WASD 移动、鼠标转向、左键射击、右键开镜、R 换弹、空格跳跃。
5. 手机上左侧拖动移动、右侧拖动转向，底部按钮执行跳跃、换弹、开镜、开火。

## Android 导出

项目使用 `export_presets.cfg` 中的 Android 预设。GitHub Actions 使用包含 Godot/Android 导出环境的 `barichello/godot-ci:4.4.1` 容器，不在 workflow 中执行 `sdkmanager` 安装步骤。

将仓库内容上传到 GitHub，打开 Actions，运行 `Hajimi Warfare Android APK`。成功后从 Artifacts 下载 `Hajimi-Warfare-APK`。

## 局域网

- 同一 Wi-Fi 下，房主点击“创建局域网房间”，默认 UDP 24567。
- 其他设备输入房主局域网 IP 后点击“加入”。
- 可在菜单中选择红方或蓝方。

**当前限制：** 这一版实现的是 ENet 房间创建/连接和阵营选择原型。还没有完整实现远端玩家模型同步、服务器权威伤害/击杀、自动发现房间、队伍平衡、反作弊或互联网匹配。请勿把它当作已完成的多人竞技游戏。

## 当前资源说明

训练场建筑、围墙、箱子和掩体由程序化几何体生成；未擅自下载来源不明或授权不清的商业贴图/模型。`assets/hajimi_original.jpg` 是用户上传的图像。
