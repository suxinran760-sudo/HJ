extends Node3D

const PORT := 24567
const MAX_PLAYERS := 8
var peer: ENetMultiplayerPeer
var team := "红方"
var players: Dictionary = {}
var score_red := 0
var score_blue := 0
var yaw := 0.0
var pitch := 0.0
var sensitivity := 0.0025
var gyro_enabled := false
var gyro_sensitivity := 1.0
var ammo := 30
var reloading := false
var health := 100
var hud: CanvasLayer
var status_label: Label
var ip_input: LineEdit
var team_picker: OptionButton
var player_body: CharacterBody3D
var camera: Camera3D
var fire_button: Button
var aim_button: Button
var move_origin := Vector2.ZERO
var look_origin := Vector2.ZERO
var move_touch := -1
var look_touch := -1
var move_vector := Vector2.ZERO
var aiming := false
var enemies: Array[Node3D] = []

func _ready() -> void:
    _build_world()
    _build_player()
    _build_hud()
    _spawn_enemies()
    _set_status("训练场就绪 · 可创建局域网房间")
    set_process(true)
    set_physics_process(true)

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    e.sky = Sky.new()
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.62, 0.68, 0.78)
    e.ambient_light_energy = 0.8
    env.environment = e
    add_child(env)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.4
    sun.shadow_enabled = true
    add_child(sun)
    _box("地面", Vector3(0,-0.5,0), Vector3(55,1,55), Color(0.22,0.27,0.25))
    # industrial training yard: walls, buildings and cover
    _box("北侧建筑", Vector3(0,3,-22), Vector3(34,6,2), Color(0.36,0.39,0.42))
    _box("南侧建筑", Vector3(0,3,22), Vector3(34,6,2), Color(0.34,0.37,0.4))
    _box("西侧围墙", Vector3(-22,2,0), Vector3(2,4,42), Color(0.42,0.39,0.34))
    _box("东侧围墙", Vector3(22,2,0), Vector3(2,4,42), Color(0.42,0.39,0.34))
    for i in range(7):
        _box("掩体_%d"%i, Vector3(-12 + i*4,0.8, (i%2)*7-3), Vector3(2.8,1.6,1.2), Color(0.38,0.31,0.23))
    _box("集装箱蓝", Vector3(-8,1.3,-10), Vector3(6,2.6,2.5), Color(0.12,0.29,0.43))
    _box("集装箱橙", Vector3(9,1.3,10), Vector3(6,2.6,2.5), Color(0.55,0.25,0.12))
    _box("中间高墙", Vector3(0,1.5,0), Vector3(1.2,3,9), Color(0.48,0.48,0.43))
    for x in [-15,15]:
        _box("瞭望建筑", Vector3(x,2.5,-14), Vector3(7,5,7), Color(0.31,0.34,0.38))

func _box(n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mesh.mesh = bm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.86
    mesh.material_override = mat
    body.add_child(mesh)
    var col := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    col.shape = shape
    body.add_child(col)
    add_child(body)

func _build_player() -> void:
    player_body = CharacterBody3D.new()
    player_body.position = Vector3(0,1,15)
    add_child(player_body)
    var col := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.38
    shape.height = 1.8
    col.shape = shape
    player_body.add_child(col)
    camera = Camera3D.new()
    camera.position = Vector3(0,0.55,0)
    camera.current = true
    player_body.add_child(camera)
    var gun := MeshInstance3D.new()
    var gm := BoxMesh.new()
    gm.size = Vector3(0.16,0.14,0.65)
    gun.mesh = gm
    gun.position = Vector3(0.28,-0.25,-0.55)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.09,0.1,0.12)
    gun.material_override = mat
    camera.add_child(gun)

func _build_hud() -> void:
    hud = CanvasLayer.new()
    add_child(hud)
    var panel := PanelContainer.new()
    panel.position = Vector2(14,14)
    panel.custom_minimum_size = Vector2(320,210)
    hud.add_child(panel)
    var v := VBoxContainer.new()
    panel.add_child(v)
    var title := Label.new()
    title.text = "哈基米枪战  |  训练场"
    title.add_theme_font_size_override("font_size",20)
    v.add_child(title)
    status_label = Label.new()
    v.add_child(status_label)
    var team_row := HBoxContainer.new()
    v.add_child(team_row)
    team_picker = OptionButton.new()
    team_picker.add_item("红方")
    team_picker.add_item("蓝方")
    team_picker.item_selected.connect(func(i): team = "红方" if i == 0 else "蓝方")
    team_row.add_child(team_picker)
    var create := Button.new()
    create.text = "创建局域网房间"
    create.pressed.connect(_host_game)
    team_row.add_child(create)
    var join_row := HBoxContainer.new()
    v.add_child(join_row)
    ip_input = LineEdit.new()
    ip_input.placeholder_text = "房主 IP，例如 192.168.1.10"
    ip_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    join_row.add_child(ip_input)
    var join := Button.new()
    join.text = "加入"
    join.pressed.connect(_join_game)
    join_row.add_child(join)
    var settings := HBoxContainer.new()
    v.add_child(settings)
    var sens := HSlider.new()
    sens.min_value = 0.5
    sens.max_value = 3.0
    sens.step = 0.1
    sens.value = 1.0
    sens.custom_minimum_size = Vector2(120,24)
    sens.value_changed.connect(func(x): sensitivity = 0.0025 * x)
    settings.add_child(Label.new())
    settings.add_child(sens)
    var gyro := CheckButton.new()
    gyro.text = "陀螺仪"
    gyro.toggled.connect(func(x): gyro_enabled = x)
    settings.add_child(gyro)
    var bottom := HBoxContainer.new()
    bottom.anchor_left = 0.5
    bottom.anchor_top = 1.0
    bottom.anchor_right = 0.5
    bottom.anchor_bottom = 1.0
    bottom.offset_left = -190
    bottom.offset_top = -78
    bottom.offset_right = 190
    bottom.offset_bottom = -16
    hud.add_child(bottom)
    var jump := Button.new()
    jump.text = "跳跃"
    jump.pressed.connect(_jump)
    bottom.add_child(jump)
    var reload_btn := Button.new()
    reload_btn.text = "换弹"
    reload_btn.pressed.connect(_reload)
    bottom.add_child(reload_btn)
    aim_button = Button.new()
    aim_button.text = "开镜"
    aim_button.toggle_mode = true
    aim_button.toggled.connect(func(x): aiming = x; camera.fov = 42.0 if x else 75.0)
    bottom.add_child(aim_button)
    fire_button = Button.new()
    fire_button.text = "开火"
    fire_button.button_down.connect(_fire)
    bottom.add_child(fire_button)
    var tip := Label.new()
    tip.text = "左侧拖动移动 · 右侧拖动视角 · 桌面 WASD / 鼠标"
    tip.anchor_left = 0.5
    tip.anchor_top = 1.0
    tip.anchor_right = 0.5
    tip.anchor_bottom = 1.0
    tip.offset_left = -230
    tip.offset_top = -110
    tip.offset_right = 230
    tip.offset_bottom = -85
    hud.add_child(tip)

func _set_status(s: String) -> void:
    if is_instance_valid(status_label):
        status_label.text = s

func _host_game() -> void:
    peer = ENetMultiplayerPeer.new()
    var err := peer.create_server(PORT, MAX_PLAYERS - 1)
    if err != OK:
        _set_status("创建房间失败：%s" % error_string(err))
        return
    multiplayer.multiplayer_peer = peer
    multiplayer.peer_connected.connect(_peer_connected)
    multiplayer.peer_disconnected.connect(_peer_disconnected)
    _set_status("房间已创建 · UDP %d · 你的阵营：%s" % [PORT, team])

func _join_game() -> void:
    var address := ip_input.text.strip_edges()
    if address.is_empty():
        _set_status("请先输入房主 IP")
        return
    peer = ENetMultiplayerPeer.new()
    var err := peer.create_client(address, PORT)
    if err != OK:
        _set_status("加入失败：%s" % error_string(err))
        return
    multiplayer.multiplayer_peer = peer
    multiplayer.connected_to_server.connect(func(): _set_status("已连接房间 · 阵营："+team))
    multiplayer.connection_failed.connect(func(): _set_status("连接失败，请检查 Wi-Fi 和 IP"))
    multiplayer.server_disconnected.connect(func(): _set_status("房主已断开"))

func _peer_connected(id: int) -> void:
    _set_status("玩家 %d 已加入 · 房间最多 8 人" % id)

func _peer_disconnected(id: int) -> void:
    _set_status("玩家 %d 已离开" % id)

func _spawn_enemies() -> void:
    for i in range(5):
        var enemy := MeshInstance3D.new()
        var mesh := CapsuleMesh.new()
        mesh.radius = 0.42
        mesh.height = 1.8
        enemy.mesh = mesh
        enemy.position = Vector3(-12+i*6,0.9,-7)
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(0.65,0.12,0.1)
        enemy.material_override = mat
        add_child(enemy)
        enemies.append(enemy)

func _physics_process(delta: float) -> void:
    if not is_instance_valid(player_body):
        return
    var input := Vector2.ZERO
    if Input.is_action_pressed("move_forward"): input.y -= 1
    if Input.is_action_pressed("move_back"): input.y += 1
    if Input.is_action_pressed("move_left"): input.x -= 1
    if Input.is_action_pressed("move_right"): input.x += 1
    input += move_vector
    input = input.limit_length(1.0)
    var dir := (player_body.global_transform.basis * Vector3(input.x,0,input.y)).normalized()
    player_body.velocity.x = dir.x * 6.0
    player_body.velocity.z = dir.z * 6.0
    if not player_body.is_on_floor():
        player_body.velocity.y -= 22.0 * delta
    elif Input.is_action_just_pressed("jump"):
        _jump()
    player_body.move_and_slide()
    if gyro_enabled and OS.get_name() == "Android":
        var gyro := Input.get_gyroscope()
        yaw -= gyro.y * gyro_sensitivity * delta
        pitch = clampf(pitch - gyro.x * gyro_sensitivity * delta,-1.2,1.2)
        _apply_look()
    if multiplayer.multiplayer_peer != null and multiplayer.is_server():
        _sync_state.rpc(player_body.position, yaw, pitch, team)

func _process(_delta: float) -> void:
    if Input.is_action_just_pressed("reload"): _reload()
    if Input.is_action_just_pressed("fire"): _fire()
    if Input.is_action_just_pressed("aim"):
        aiming = not aiming
        camera.fov = 42.0 if aiming else 75.0
    if Input.is_action_just_pressed("jump"): _jump()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        yaw -= event.relative.x * sensitivity
        pitch = clampf(pitch - event.relative.y * sensitivity,-1.2,1.2)
        _apply_look()
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().size.x * 0.45 and move_touch == -1:
                move_touch = event.index
                move_origin = event.position
            elif look_touch == -1:
                look_touch = event.index
                look_origin = event.position
        else:
            if event.index == move_touch:
                move_touch = -1
                move_vector = Vector2.ZERO
            if event.index == look_touch:
                look_touch = -1
    if event is InputEventScreenDrag:
        if event.index == move_touch:
            move_vector = ((event.position - move_origin) / 90.0).limit_length(1.0)
        elif event.index == look_touch:
            yaw -= event.relative.x * sensitivity * 1.7
            pitch = clampf(pitch - event.relative.y * sensitivity * 1.7,-1.2,1.2)
            _apply_look()

func _apply_look() -> void:
    player_body.rotation.y = yaw
    camera.rotation.x = pitch

func _jump() -> void:
    if player_body.is_on_floor():
        player_body.velocity.y = 7.0

func _reload() -> void:
    if reloading or ammo == 30: return
    reloading = true
    _set_status("换弹中…")
    await get_tree().create_timer(1.4).timeout
    ammo = 30
    reloading = false
    _set_status("换弹完成 · 30/30")

func _fire() -> void:
    if reloading or ammo <= 0:
        return
    ammo -= 1
    var from := camera.global_position
    var to := from + -camera.global_transform.basis.z * 100.0
    var query := PhysicsRayQueryParameters3D.create(from,to)
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.is_empty():
        _set_status("命中目标！弹药 %d/30" % ammo)
    else:
        _set_status("开火 · 弹药 %d/30" % ammo)

@rpc("authority", "call_remote", "unreliable")
func _sync_state(pos: Vector3, remote_yaw: float, remote_pitch: float, remote_team: String) -> void:
    pass
